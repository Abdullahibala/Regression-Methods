import pandas as pd
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
from sklearn.metrics import confusion_matrix, classification_report

# ------------------------------------------------------------
# 1. LOAD DATASET
# ------------------------------------------------------------
df = pd.read_csv("smarket.csv")   # use the version given by your instructor

# Convert target to categorical if needed
df["Direction"] = df["Direction"].astype("category")

# ------------------------------------------------------------
# 2. TRAIN–TEST SPLIT USING YEARS
# ------------------------------------------------------------
train = df[df["Year"] < 2005]
test = df[df["Year"] == 2005]

X_train = train[["Lag1", "Lag2"]]
y_train = train["Direction"]

X_test = test[["Lag1", "Lag2"]]
y_test = test["Direction"]

# ------------------------------------------------------------
# 3. LDA
# ------------------------------------------------------------
lda = LinearDiscriminantAnalysis()
lda.fit(X_train, y_train)

# Outputs required by assignment
priors_lda = lda.priors_
means_lda = lda.means_
coef_lda = lda.coef_

# Predictions
pred_lda = lda.predict(X_test)

# Confusion matrix
cm_lda = confusion_matrix(y_test, pred_lda)

print("==== LDA RESULTS ====")
print("Prior Probabilities:", priors_lda)
print("\nGroup Means:\n", means_lda)
print("\nCoefficients:\n", coef_lda)
print("\nConfusion Matrix:\n", cm_lda)
print("\nClassification Report:\n", classification_report(y_test, pred_lda))

# ------------------------------------------------------------
# 4. QDA
# ------------------------------------------------------------
qda = QuadraticDiscriminantAnalysis()
qda.fit(X_train, y_train)

# Outputs for assignment
priors_qda = qda.priors_
means_qda = qda.means_

# Predictions
pred_qda = qda.predict(X_test)

# Confusion matrix
cm_qda = confusion_matrix(y_test, pred_qda)

print("\n\n==== QDA RESULTS ====")
print("Prior Probabilities:", priors_qda)
print("\nGroup Means:\n", means_qda)
print("\nConfusion Matrix:\n", cm_qda)
print("\nClassification Report:\n", classification_report(y_test, pred_qda))
