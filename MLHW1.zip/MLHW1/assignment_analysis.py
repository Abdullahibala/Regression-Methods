# assignment_analysis.py
# Requirements: pandas, numpy, scikit-learn, matplotlib
# Save as .py or paste into a notebook cell and run.

import os, glob
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_squared_error, mean_absolute_error
import matplotlib.pyplot as plt

# ---------- 1) find & load the dataset ----------
# Adjust this path if running locally
data_dir = r"C:\Users\Abdullahi Bala\Downloads\Machine learning hw1\datasets"

# Load any CSV file in the folder
csv_files = glob.glob(os.path.join(data_dir, "*.csv"))


if not csv_files:
    raise FileNotFoundError(f"No CSV files found in {data_dir}. Please place housing CSV there and try again.")
# prefer file with 'housing' in the name
chosen = None
for f in csv_files:
    if 'housing' in os.path.basename(f).lower():
        chosen = f
        break
if chosen is None:
    chosen = csv_files[0]
print("Loading:", chosen)
df = pd.read_csv(chosen)
print("Loaded shape:", df.shape)

# print columns to confirm
print("Columns:")
for c in df.columns:
    print("  ", repr(c))

# ---------- 2) normalize column names for robust matching ----------
cols_norm = [str(c).strip().replace('\xa0',' ').replace(' ', '_') for c in df.columns]
df.columns = cols_norm
print("Normalized columns:", df.columns.tolist())

# ---------- 3) find target and drop problematic/categorical features ----------
# target detection: a column that contains median, house and value words
target_candidates = [c for c in df.columns if 'median' in c.lower() and 'house' in c.lower() and 'value' in c.lower()]
if not target_candidates:
    # fallback common name
    if 'median_house_value' in df.columns:
        target = 'median_house_value'
    else:
        raise ValueError("Target column not detected. Look for 'median_house_value' in columns.")
else:
    target = target_candidates[0]
print("Using target:", target)

# drop total_bedrooms if present (assignment tip)
total_bed = None
for c in df.columns:
    if 'total' in c.lower() and 'bed' in c.lower():
        total_bed = c
        break
if total_bed:
    print("Dropping total_bedrooms-like column:", total_bed)
    df = df.drop(columns=[total_bed])

# identify categorical columns and drop them (e.g. ocean_proximity)
cat_cols = [c for c in df.columns if df[c].dtype == object or df[c].dtype.name == 'category']
print("Categorical columns detected (will be dropped for linear models):", cat_cols)
df_numeric = df.drop(columns=cat_cols).copy()

# ensure we have numeric features
numeric_features = [c for c in df_numeric.columns if c != target]
print("Numeric features to be used:", numeric_features)

# drop rows with NaNs in numeric features or target (simple handling)
df_numeric = df_numeric.dropna(subset=numeric_features + [target])
print("Numeric df shape after dropping NaNs:", df_numeric.shape)

# ---------- 4) Train-test split (30% test, shuffle=True) for per-feature & multivariate tasks ----------
X = df_numeric[numeric_features]
y = df_numeric[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, shuffle=True, random_state=42)

# ---------- 5) Per-feature linear regression (single-feature models) ----------
per_feature_results = []
for feat in numeric_features:
    Xtr = np.array(X_train[feat]).reshape(-1,1)
    Xte = np.array(X_test[feat]).reshape(-1,1)
    scaler = StandardScaler()
    Xtr_s = scaler.fit_transform(Xtr)
    Xte_s = scaler.transform(Xte)
    model = LinearRegression()
    model.fit(Xtr_s, y_train)
    y_pred = model.predict(Xte_s)
    sse = float(np.sum((y_pred - y_test)**2))
    mse = float(mean_squared_error(y_test, y_pred))
    mae = float(mean_absolute_error(y_test, y_pred))
    coef = float(model.coef_[0])
    intercept = float(model.intercept_)
    per_feature_results.append({
        'feature': feat,
        'coef': coef,
        'intercept': intercept,
        'SSE': sse,
        'MSE': mse,
        'MAE': mae
    })

res_df = pd.DataFrame(per_feature_results).sort_values('feature').reset_index(drop=True)
print("\nPer-feature metrics:\n", res_df)

# best features per measure
best_sse = res_df.loc[res_df['SSE'].idxmin()].to_dict()
best_mse = res_df.loc[res_df['MSE'].idxmin()].to_dict()
best_mae = res_df.loc[res_df['MAE'].idxmin()].to_dict()
print("\nBest by SSE:", best_sse)
print("Best by MSE:", best_mse)
print("Best by MAE:", best_mae)

# plots: MSE, MAE, SSE vs feature
features = res_df['feature'].tolist()
x = np.arange(len(features))

plt.figure(figsize=(10,5))
plt.plot(x, res_df['MSE'].values, marker='o')
plt.xticks(x, features, rotation=45, ha='right')
plt.title('Per-feature MSE (test set)')
plt.ylabel('MSE')
plt.tight_layout()
plt.show()

plt.figure(figsize=(10,5))
plt.plot(x, res_df['MAE'].values, marker='o')
plt.xticks(x, features, rotation=45, ha='right')
plt.title('Per-feature MAE (test set)')
plt.ylabel('MAE')
plt.tight_layout()
plt.show()

plt.figure(figsize=(10,5))
plt.plot(x, res_df['SSE'].values, marker='o')
plt.xticks(x, features, rotation=45, ha='right')
plt.title('Per-feature SSE (test set)')
plt.ylabel('SSE')
plt.tight_layout()
plt.show()

# ---------- 6) Multivariate linear regression (all numeric features together) ----------
scaler_all = StandardScaler()
Xtr_all = scaler_all.fit_transform(X_train)
Xte_all = scaler_all.transform(X_test)
lr_all = LinearRegression()
lr_all.fit(Xtr_all, y_train)
y_pred_all = lr_all.predict(Xte_all)
sse_all = float(np.sum((y_pred_all - y_test)**2))
mse_all = float(mean_squared_error(y_test, y_pred_all))
mae_all = float(mean_absolute_error(y_test, y_pred_all))
coefs_all = dict(zip(numeric_features, lr_all.coef_.tolist()))

print("\nMultivariate linear regression results:")
print("SSE:", sse_all, "MSE:", mse_all, "MAE:", mae_all)
print("Coefficients per feature:")
for k,v in coefs_all.items():
    print(" ", k, ":", v)

# ---------- 7) Ridge and Lasso with 5-fold cross validation (use full numeric dataset, no prior train-test split) ----------
alphas = np.logspace(-4, 4, 50)
ridge_means = []
ridge_stds = []
lasso_means = []
lasso_stds = []
cv = KFold(n_splits=5, shuffle=True, random_state=42)

for a in alphas:
    ridge_pipe = Pipeline([('scaler', StandardScaler()), ('est', Ridge(alpha=a, random_state=42))])
    scores = cross_val_score(ridge_pipe, X, y, scoring='neg_mean_squared_error', cv=cv)
    mses = -scores
    ridge_means.append(mses.mean())
    ridge_stds.append(mses.std())

    lasso_pipe = Pipeline([('scaler', StandardScaler()), ('est', Lasso(alpha=a, max_iter=20000, random_state=42))])
    scores_l = cross_val_score(lasso_pipe, X, y, scoring='neg_mean_squared_error', cv=cv)
    mses_l = -scores_l
    lasso_means.append(mses_l.mean())
    lasso_stds.append(mses_l.std())

ridge_means = np.array(ridge_means); ridge_stds = np.array(ridge_stds)
lasso_means = np.array(lasso_means); lasso_stds = np.array(lasso_stds)

best_ridge_idx = np.argmin(ridge_means)
best_lasso_idx = np.argmin(lasso_means)
best_ridge_alpha = alphas[best_ridge_idx]
best_lasso_alpha = alphas[best_lasso_idx]

print("\nRidge best alpha:", best_ridge_alpha, "mean MSE:", ridge_means[best_ridge_idx], "std:", ridge_stds[best_ridge_idx])
print("Lasso best alpha:", best_lasso_alpha, "mean MSE:", lasso_means[best_lasso_idx], "std:", lasso_stds[best_lasso_idx])

plt.figure(figsize=(8,5))
plt.semilogx(alphas, ridge_means, marker='o')
plt.fill_between(alphas, ridge_means - ridge_stds, ridge_means + ridge_stds, alpha=0.2)
plt.title('Ridge CV mean MSE vs alpha (5-fold)')
plt.xlabel('alpha')
plt.ylabel('Mean MSE')
plt.tight_layout()
plt.show()

plt.figure(figsize=(8,5))
plt.semilogx(alphas, lasso_means, marker='o')
plt.fill_between(alphas, lasso_means - lasso_stds, lasso_means + lasso_stds, alpha=0.2)
plt.title('Lasso CV mean MSE vs alpha (5-fold)')
plt.xlabel('alpha')
plt.ylabel('Mean MSE')
plt.tight_layout()
plt.show()

# ---------- 8) Save CSV outputs to results folder ----------
out_dir = os.path.join(data_dir, "assignment_results")
os.makedirs(out_dir, exist_ok=True)
res_df.to_csv(os.path.join(out_dir, "per_feature_metrics.csv"), index=False)
pd.DataFrame({'feature': list(coefs_all.keys()), 'coef': list(coefs_all.values())}).to_csv(os.path.join(out_dir, "multivariate_coefs.csv"), index=False)
pd.DataFrame({'alpha': alphas, 'ridge_mean_mse': ridge_means, 'ridge_std': ridge_stds}).to_csv(os.path.join(out_dir, "ridge_cv.csv"), index=False)
pd.DataFrame({'alpha': alphas, 'lasso_mean_mse': lasso_means, 'lasso_std': lasso_stds}).to_csv(os.path.join(out_dir, "lasso_cv.csv"), index=False)
print("Saved CSVs to:", out_dir)

# ---------- 9) Short textual summary that you can paste in the report ----------
summary_text = f"""
Per-feature evaluation: see per_feature_metrics.csv (SSE, MSE, MAE, coefficient).
Best features:
 - Best (min SSE): {best_sse['feature']} (SSE={best_sse['SSE']:.2f})
 - Best (min MSE): {best_mse['feature']} (MSE={best_mse['MSE']:.2f})
 - Best (min MAE): {best_mae['feature']} (MAE={best_mae['MAE']:.2f})

Multivariate linear regression (all numeric features):
 - SSE: {sse_all:.2f}, MSE: {mse_all:.2f}, MAE: {mae_all:.2f}
 - Coefficients: see multivariate_coefs.csv

Regularization (5-fold CV):
 - Ridge best alpha: {best_ridge_alpha} (mean MSE: {ridge_means[best_ridge_idx]:.2f})
 - Lasso best alpha: {best_lasso_alpha} (mean MSE: {lasso_means[best_lasso_idx]:.2f})

All saved outputs are in the folder: {out_dir}
"""
print(summary_text)
